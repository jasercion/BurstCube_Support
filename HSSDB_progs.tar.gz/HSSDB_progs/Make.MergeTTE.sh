
#  Michael S. Briggs, 2008 June 22, UAH / NSSTC.

gcc-mp-7  -Wall -Wextra -O2  \
    MAIN_Merge_TTE.c   IntegerTime_from_CoarseFine.c  \
  -o Merge_TTE.exe
