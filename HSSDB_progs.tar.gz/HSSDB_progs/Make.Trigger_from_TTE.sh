
#  Michael S. Briggs, 2008 July 7, UAH / NSSTC.

gcc-mp-7  -Wall -Wextra -O2  \
    Trigger_from_TTE.c     \
  -o Trigger_from_TTE.exe
